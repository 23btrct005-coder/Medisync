package com.health.medisync.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "reports")
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false)
    @JsonIgnoreProperties({"doctors", "user", "medicalRecords", "reports", "appointments"})
    private Patient patient;

    private String fileName;
    private String fileType;
    private String reportCategory; // LAB, IMAGING, PRESCRIPTION, OTHER

    @JsonIgnore
    @JdbcTypeCode(SqlTypes.BINARY)
    @Column(name = "file_data")
    private byte[] fileData;
    
    private LocalDate uploadDate;
    private LocalDate documentDate;

    @Column(columnDefinition = "TEXT")
    private String aiSummary;

    private String monaiDiagnosis;
    private Double monaiConfidence;

    @Column(columnDefinition = "TEXT")
    private String clinicalReasoning;

    @Column(columnDefinition = "TEXT")
    private String doctorNotes;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Patient getPatient() { return patient; }
    public void setPatient(Patient patient) { this.patient = patient; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getFileType() { return fileType; }
    public void setFileType(String fileType) { this.fileType = fileType; }
    public String getReportCategory() { return reportCategory; }
    public void setReportCategory(String reportCategory) { this.reportCategory = reportCategory; }

    public byte[] getFileData() { return fileData; }
    public void setFileData(byte[] fileData) { this.fileData = fileData; }

    public LocalDate getUploadDate() { return uploadDate; }
    public void setUploadDate(LocalDate uploadDate) { this.uploadDate = uploadDate; }

    public LocalDate getDocumentDate() { return documentDate; }
    public void setDocumentDate(LocalDate documentDate) { this.documentDate = documentDate; }

    public String getAiSummary() { return aiSummary; }
    public void setAiSummary(String aiSummary) { this.aiSummary = aiSummary; }

    public String getMonaiDiagnosis() { return monaiDiagnosis; }
    public void setMonaiDiagnosis(String monaiDiagnosis) { this.monaiDiagnosis = monaiDiagnosis; }

    public Double getMonaiConfidence() { return monaiConfidence; }
    public void setMonaiConfidence(Double monaiConfidence) { this.monaiConfidence = monaiConfidence; }

    public String getClinicalReasoning() { return clinicalReasoning; }
    public void setClinicalReasoning(String clinicalReasoning) { this.clinicalReasoning = clinicalReasoning; }

    public String getDoctorNotes() { return doctorNotes; }
    public void setDoctorNotes(String doctorNotes) { this.doctorNotes = doctorNotes; }
}
