package com.health.medisync.service;

import com.health.medisync.model.*;
import com.health.medisync.repository.*;
import com.health.medisync.service.DatabaseSchemaService;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import org.springframework.transaction.annotation.Transactional;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class DoctorService {
    private final DoctorRepository doctorRepository;
    private final UserRepository userRepository;
    private final PatientRepository patientRepository;
    private final MedicalRecordRepository recordRepository;
    private final ReportRepository reportRepository;
    private final AccessRequestRepository accessRequestRepository;
    private final AppointmentRepository appointmentRepository;
    private final SupabaseStorageService supabaseStorageService;
    private final NotificationService notificationService;
    private final AuditLogService auditLogService;
    private final DatabaseSchemaService databaseSchemaService;

    public DoctorService(DoctorRepository doctorRepository, UserRepository userRepository,
                         PatientRepository patientRepository, MedicalRecordRepository recordRepository,
                         ReportRepository reportRepository, AccessRequestRepository accessRequestRepository,
                         AppointmentRepository appointmentRepository,
                         SupabaseStorageService supabaseStorageService,
                         NotificationService notificationService,
                         AuditLogService auditLogService,
                         DatabaseSchemaService databaseSchemaService) {
        this.doctorRepository = doctorRepository;
        this.userRepository = userRepository;
        this.patientRepository = patientRepository;
        this.recordRepository = recordRepository;
        this.reportRepository = reportRepository;
        this.accessRequestRepository = accessRequestRepository;
        this.appointmentRepository = appointmentRepository;
        this.supabaseStorageService = supabaseStorageService;
        this.notificationService = notificationService;
        this.auditLogService = auditLogService;
        this.databaseSchemaService = databaseSchemaService;
    }

    public Doctor getDoctorProfile(String username) {
        // Safety: Ensure schema is synchronized before fetching the complex Doctor entity
        databaseSchemaService.selfHealSchema();
        
        User user = userRepository.findByUsernameIgnoreCase(username)
            .orElseThrow(() -> new RuntimeException("User not found"));
        return doctorRepository.findByUserId(user.getId())
            .orElseThrow(() -> new RuntimeException("Doctor profile not found. Please complete your registration."));
    }

    public List<Patient> getLinkedPatients(String doctorUsername) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        return patientRepository.findByDoctorIdAndUserId(doctor.getId(), doctor.getUser().getId());
    }

    public void requestAccess(String doctorUsername, String patientEmail) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        Patient patient = patientRepository.findByUserUsernameIgnoreCase(patientEmail)
            .orElseThrow(() -> new RuntimeException("Patient with email/username " + patientEmail + " not found"));
        createAccessRequest(doctor, patient);
    }

    public void requestAccess(String doctorUsername, Long patientId) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        Patient patient = patientRepository.findById(patientId)
            .orElseThrow(() -> new RuntimeException("Patient not found"));
        createAccessRequest(doctor, patient);
    }

    private void createAccessRequest(Doctor doctor, Patient patient) {
        accessRequestRepository.findByDoctorAndPatient(doctor, patient).ifPresent(existing -> {
            if ("REJECTED".equals(existing.getStatus()) || "REVOKED".equals(existing.getStatus())) {
                existing.setStatus("PENDING");
                accessRequestRepository.save(existing);
                
                // Notify Patient (Re-request)
                notificationService.sendNotification(
                    patient.getUser().getId(),
                    "SECURITY",
                    "Access Re-authentication Requested",
                    "Dr. " + doctor.getName() + " has requested to re-link with your clinical profile.",
                    "/dashboard",
                    "Review Request"
                );
                return;
            }
            throw new RuntimeException("A link request already exists between you and this patient (Status: " + existing.getStatus() + ")");
        });

        if (accessRequestRepository.findByDoctorAndPatient(doctor, patient).isEmpty()) {
            AccessRequest req = new AccessRequest();
            req.setDoctor(doctor);
            req.setPatient(patient);
            req.setStatus("PENDING");
            accessRequestRepository.save(req);

            // Notify Patient
            notificationService.sendNotification(
                patient.getUser().getId(),
                "SECURITY",
                "New Access Request",
                "Dr. " + doctor.getName() + " has requested access to your clinical profile.",
                "/dashboard",
                "Respond Now"
            );
        }
    }

    private void verifyAccess(Doctor doctor, Long patientId) {
        // Authoritative Check: Is this patient in the doctor's verified census?
        List<Patient> linkedPatients = patientRepository.findByDoctorIdAndUserId(doctor.getId(), doctor.getUser().getId());
        boolean hasAccess = linkedPatients.stream().anyMatch(p -> p.getId().equals(patientId));
            
        // Secondary Protocol: Check for confirmed clinical engagement (Appointment)
        if (!hasAccess) {
            hasAccess = appointmentRepository.existsByDoctorIdAndPatientIdAndStatus(
                doctor.getId(), patientId, Appointment.AppointmentStatus.BOOKED);
        }

        if (!hasAccess) {
            throw new RuntimeException("Unauthorized Access: This patient is not linked to your clinical practice. Please use the Patient Code to establish a secure link.");
        }
        
        // Security Logging
        auditLogService.log(
            doctor.getUser().getId(),
            doctor.getName(),
            "ACCESS_VIEW",
            patientId,
            "Doctor accessed full patient clinical dossier"
        );
    }

    public Patient getPatientById(String doctorUsername, Long id) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        verifyAccess(doctor, id);
        Patient patient = patientRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Clinical telemetry for subject #" + id + " not found in the local ledger."));
        
        // Determine if there is a permanent link
        boolean isPermanentlyLinked = patient.getDoctors().stream().anyMatch(d -> d.getId().equals(doctor.getId()));
        patient.setLinked(isPermanentlyLinked);
        
        return patient;
    }

    public List<MedicalRecord> getPatientRecords(String doctorUsername, Long patientId) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        verifyAccess(doctor, patientId);
        return recordRepository.findByPatientId(patientId);
    }

    public List<Report> getPatientReports(String doctorUsername, Long patientId) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        verifyAccess(doctor, patientId);
        return reportRepository.findByPatientId(patientId);
    }

    public List<AccessRequest> getDoctorRequests(String doctorUsername) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        return accessRequestRepository.findByDoctor(doctor);
    }

    public MedicalRecord addMedicalRecord(String doctorUsername, Long patientId, MedicalRecordRequest request) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        Patient patient = getPatientById(doctorUsername, patientId);

        MedicalRecord record = new MedicalRecord();
        record.setPatient(patient);
        record.setDiagnosis(request.getDiagnosis());
        record.setPrescription(request.getPrescription());
        record.setDate(request.getDate() != null ? request.getDate() : java.time.LocalDate.now());
        record.setDoctorName(doctor.getName());

        MedicalRecord saved = recordRepository.save(record);

        // Security Logging
        auditLogService.log(
            doctor.getUser().getId(),
            doctor.getName(),
            "RECORD_CREATE",
            patientId,
            "Logged new clinical diagnosis"
        );

        // Notify Patient
        notificationService.sendNotification(
            patient.getUser().getId(),
            "APPOINTMENT",
            "Medical Record Added",
            "A new clinical diagnosis has been logged by Dr. " + doctor.getName() + ".",
            "/dashboard/records",
            "View Records"
        );

        return saved;
    }

    @Transactional
    public Doctor updateProfile(String doctorUsername, Map<String, Object> updates) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        System.out.println("DEBUG: Profile sync for " + doctorUsername);
        System.out.println("DEBUG: Incoming updates: " + updates);

        List<String> changedFields = new ArrayList<>();
        
        // Track Changes for Governance
        trackChange("Name", doctor.getName(), (String) updates.get("name"), changedFields);
        trackChange("Phone", doctor.getPhone(), (String) updates.get("phone"), changedFields);
        trackChange("Specialization", doctor.getSpecialization(), (String) updates.get("specialization"), changedFields);
        trackChange("Consultation Fee", doctor.getConsultationFee(), updates.get("consultationFee") != null ? updates.get("consultationFee").toString() : null, changedFields);
        trackChange("Clinical Window", doctor.getConsultationTimings(), (String) updates.get("consultationTimings"), changedFields);
        trackChange("Clinic Address", doctor.getClinicAddress(), (String) updates.get("clinicAddress"), changedFields);
        trackChange("Clinical Services", doctor.getServices(), (String) updates.get("services"), changedFields);
        trackChange("Direct UPI", doctor.getUpiId(), (String) updates.get("upiId"), changedFields);
        trackChange("Settlement Account", doctor.getRazorpayAccountId(), (String) updates.get("razorpayAccountId"), changedFields);
        
        // Handle Numeric conversions with care
        if (updates.containsKey("yearsOfExperience")) {
            Integer oldExp = doctor.getYearsOfExperience();
            try {
                Object exp = updates.get("yearsOfExperience");
                Integer newExp = (exp instanceof Number) ? ((Number) exp).intValue() : Integer.parseInt(exp.toString().trim());
                if (!Objects.equals(oldExp, newExp)) changedFields.add("Experience (" + newExp + " years)");
            } catch (Exception e) {}
        }
        
        if (updates.containsKey("name")) doctor.setName((String) updates.get("name"));
        if (updates.containsKey("phone")) doctor.setPhone((String) updates.get("phone"));
        if (updates.containsKey("alternatePhone")) doctor.setAlternatePhone((String) updates.get("alternatePhone"));
        if (updates.containsKey("specialization")) doctor.setSpecialization((String) updates.get("specialization"));
        if (updates.containsKey("medicalDegree")) doctor.setMedicalDegree((String) updates.get("medicalDegree"));
        if (updates.containsKey("medicalLicenseNumber")) doctor.setMedicalLicenseNumber((String) updates.get("medicalLicenseNumber"));
        if (updates.containsKey("hospital")) doctor.setHospital((String) updates.get("hospital"));
        if (updates.containsKey("college")) doctor.setCollege((String) updates.get("college"));
        if (updates.containsKey("additionalCertifications")) doctor.setAdditionalCertifications((String) updates.get("additionalCertifications"));
        
        if (updates.containsKey("yearsOfExperience")) {
            Object exp = updates.get("yearsOfExperience");
            if (exp != null && !exp.toString().trim().isEmpty()) {
                try {
                    if (exp instanceof Number) {
                        doctor.setYearsOfExperience(((Number) exp).intValue());
                    } else {
                        doctor.setYearsOfExperience(Integer.parseInt(exp.toString().trim()));
                    }
                } catch (NumberFormatException e) {
                    System.err.println("DEBUG: Failed to parse yearsOfExperience: " + exp);
                }
            }
        }
        
        if (updates.containsKey("consultationFee")) doctor.setConsultationFee(updates.get("consultationFee") != null ? updates.get("consultationFee").toString() : "");
        if (updates.containsKey("workingDays")) doctor.setWorkingDays((String) updates.get("workingDays"));
        if (updates.containsKey("consultationTimings")) doctor.setConsultationTimings((String) updates.get("consultationTimings"));
        if (updates.containsKey("onlineConsultation")) doctor.setOnlineConsultation((Boolean) updates.get("onlineConsultation"));

        // Direct Payment Details
        if (updates.containsKey("clinicAddress")) doctor.setClinicAddress((String) updates.get("clinicAddress"));
        if (updates.containsKey("razorpayAccountId")) doctor.setRazorpayAccountId((String) updates.get("razorpayAccountId"));
        if (updates.containsKey("upiId")) doctor.setUpiId((String) updates.get("upiId"));
        if (updates.containsKey("preferredPaymentMode")) doctor.setPreferredPaymentMode((String) updates.get("preferredPaymentMode"));
        if (updates.containsKey("appointmentsEnabled")) doctor.setAppointmentsEnabled((Boolean) updates.get("appointmentsEnabled"));
        if (updates.containsKey("services")) doctor.setServices((String) updates.get("services"));
        if (updates.containsKey("serviceDurations")) doctor.setServiceDurations((String) updates.get("serviceDurations"));
        if (updates.containsKey("serviceCapacity")) doctor.setServiceCapacity((String) updates.get("serviceCapacity"));
        
        if (updates.containsKey("onlineConsultationFee")) {
            Object fee = updates.get("onlineConsultationFee");
            if (fee != null && !fee.toString().trim().isEmpty()) {
                try {
                    doctor.setOnlineConsultationFee(Double.parseDouble(fee.toString().trim()));
                } catch (NumberFormatException e) {
                    System.err.println("DEBUG: Failed to parse onlineConsultationFee: " + fee);
                }
            }
        }
        if (updates.containsKey("offlineConsultationFee")) {
            Object fee = updates.get("offlineConsultationFee");
            if (fee != null && !fee.toString().trim().isEmpty()) {
                try {
                    doctor.setOfflineConsultationFee(Double.parseDouble(fee.toString().trim()));
                } catch (NumberFormatException e) {
                    System.err.println("DEBUG: Failed to parse offlineConsultationFee: " + fee);
                }
            }
        }

        if (doctor.getOnlineConsultationFee() == null && doctor.getConsultationFee() != null) {
           String numeric = doctor.getConsultationFee().replaceAll("[^0-9]", "");
           if (!numeric.isEmpty()) {
               try { 
                   double val = Double.parseDouble(numeric);
                   doctor.setOnlineConsultationFee(val);
                   if (doctor.getOfflineConsultationFee() == null) {
                       doctor.setOfflineConsultationFee(val);
                   }
               } catch (Exception e) {}
           }
        }

        // New Professional & Clinical Fields
        if (updates.containsKey("medicalCouncil")) doctor.setMedicalCouncil((String) updates.get("medicalCouncil"));
        if (updates.containsKey("licenseExpiryDate")) doctor.setLicenseExpiryDate((String) updates.get("licenseExpiryDate"));
        if (updates.containsKey("registrationYear")) {
            Object regYear = updates.get("registrationYear");
            if (regYear != null && !regYear.toString().isEmpty()) {
                doctor.setRegistrationYear(Integer.parseInt(regYear.toString()));
            }
        }
        
        if (updates.containsKey("subSpecialties")) doctor.setSubSpecialties((String) updates.get("subSpecialties"));
        if (updates.containsKey("proceduresHandled")) doctor.setProceduresHandled((String) updates.get("proceduresHandled"));
        if (updates.containsKey("treatmentFocus")) doctor.setTreatmentFocus((String) updates.get("treatmentFocus"));
        if (updates.containsKey("languagesSpoken")) doctor.setLanguagesSpoken((String) updates.get("languagesSpoken"));
        if (updates.containsKey("publications")) doctor.setPublications((String) updates.get("publications"));
        if (updates.containsKey("services")) doctor.setServices((String) updates.get("services"));
        if (updates.containsKey("serviceFees") && !doctor.isInstitutional()) doctor.setServiceFees((String) updates.get("serviceFees"));
        if (updates.containsKey("serviceDurations") && !doctor.isInstitutional()) doctor.setServiceDurations((String) updates.get("serviceDurations"));
        
        if (updates.containsKey("slotDuration")) {
            Object duration = updates.get("slotDuration");
            if (duration != null && !duration.toString().isEmpty()) {
                doctor.setSlotDuration(Integer.parseInt(duration.toString()));
            }
        }
        if (updates.containsKey("maxPatientsPerDay")) {
            Object maxP = updates.get("maxPatientsPerDay");
            if (maxP != null && !maxP.toString().isEmpty()) {
                doctor.setMaxPatientsPerDay(Integer.parseInt(maxP.toString()));
            }
        }
        if (updates.containsKey("breakTimings")) doctor.setBreakTimings((String) updates.get("breakTimings"));
        if (updates.containsKey("absenceDates")) {
            trackChange("Leave Schedule", doctor.getAbsenceDates(), (String) updates.get("absenceDates"), changedFields);
            doctor.setAbsenceDates((String) updates.get("absenceDates"));
        }
        if (updates.containsKey("slotBuffer")) {
            Object buffer = updates.get("slotBuffer");
            if (buffer != null && !buffer.toString().isEmpty()) {
                doctor.setSlotBuffer(Integer.parseInt(buffer.toString()));
            }
        }

        doctorRepository.save(doctor);
        
        // Trigger server-side geocoding for independent clinic location
        syncDoctorCoordinates(doctor);
        
        // Institutional Governance: Notify Admin of changes
        if (!changedFields.isEmpty() && doctor.getHospitalEntity() != null) {
            String changeSummary = String.join(", ", changedFields);
            Hospital hospital = doctor.getHospitalEntity();
            
            System.out.println("INFO: Notifying Admins of " + hospital.getName() + " about profile changes for Dr. " + doctor.getName());
            
            if (hospital.getAdmins() != null) {
                for (HospitalAdmin admin : hospital.getAdmins()) {
                    if (admin.isApproved()) {
                        notificationService.sendNotification(
                            admin.getUser().getId(),
                            "INSTITUTIONAL",
                            "Staff Profile Update",
                            "Dr. " + doctor.getName() + " has updated clinical profile parameters: " + changeSummary,
                            "/hospital-dashboard/staff",
                            "Review Staff"
                        );
                    }
                }
            }
        }

        return doctor;
    }

    private void trackChange(String fieldName, Object oldVal, Object newVal, List<String> changes) {
        if (newVal == null && oldVal == null) return;
        String sOld = oldVal != null ? oldVal.toString().trim() : "";
        String sNew = newVal != null ? newVal.toString().trim() : "";
        
        if (!sOld.equals(sNew)) {
            changes.add(fieldName);
        }
    }

    public void updateProfilePhoto(String username, org.springframework.web.multipart.MultipartFile photo) {
        Doctor doctor = getDoctorProfile(username);
        String photoUrl = supabaseStorageService.uploadFile(photo);
        if (photoUrl != null) {
            doctor.setProfilePictureUrl(photoUrl);
            doctorRepository.save(doctor);
        }
    }

    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    public Patient getPatientByShortCode(String shortCode) {
        return patientRepository.findByPatientId(shortCode.toUpperCase().trim())
            .orElseThrow(() -> new RuntimeException("Patient with ID " + shortCode + " not found."));
    }

    public List<Doctor> searchDoctors(String query) {
        if (query == null || query.trim().isEmpty()) {
            return doctorRepository.findByApprovedTrue();
        }
        return doctorRepository.searchDoctors(query);
    }

    @org.springframework.transaction.annotation.Transactional
    public void unlockHistoryWithPasscode(String doctorUsername, String patientShortCode, String passcode) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        Patient patient = patientRepository.findByPatientId(patientShortCode.toUpperCase().trim())
            .orElseThrow(() -> new RuntimeException("Patient with ID " + patientShortCode + " not found."));
        
        if (patient.getHistoryPasscode() == null || !patient.getHistoryPasscode().equals(passcode)) {
            throw new RuntimeException("Invalid Clinical Passcode. Access Denied.");
        }

        // Link the doctor and patient immediately
        patient.getDoctors().add(doctor);
        patientRepository.save(patient);

        // Also update/create access request to APPROVED state
        AccessRequest req = accessRequestRepository.findByDoctorAndPatient(doctor, patient)
            .orElse(new AccessRequest());
        req.setDoctor(doctor);
        req.setPatient(patient);
        req.setStatus("ACCEPTED");
        accessRequestRepository.save(req);

        // Security Logging
        auditLogService.log(
            doctor.getUser().getId(),
            doctor.getName(),
            "VAULT_UNLOCK",
            patient.getId(),
            "Doctor unlocked clinical vault using direct passcode"
        );

        // Notify Patient
        notificationService.sendNotification(
            patient.getUser().getId(),
            "SECURITY",
            "Vault Unlocked via Passcode",
            "Dr. " + doctor.getName() + " has accessed your full clinical history using your direct passcode.",
            "/dashboard/history",
            "View Access Log"
        );
    }

    public Map<String, Object> getRevenueAnalytics(String doctorUsername) {
        Doctor doctor = getDoctorProfile(doctorUsername);
        List<Appointment> appointments = appointmentRepository.findRevenueAppointments(doctor.getId());

        java.time.LocalDate today = java.time.LocalDate.now();
        double todayRevenue = 0;
        double weekRevenue = 0;
        double monthRevenue = 0;
        double totalRevenue = 0;

        java.util.Map<String, Double> monthlyHistory = new java.util.LinkedHashMap<>();

        for (Appointment appt : appointments) {
            double amt = appt.getAmount() != null ? appt.getAmount() : 0;
            totalRevenue += amt;

            java.time.LocalDate date = appt.getAppointmentDate();
            if (date.equals(today)) todayRevenue += amt;
            if (!date.isBefore(today.minusWeeks(1))) weekRevenue += amt;
            if (!date.isBefore(today.minusMonths(1))) monthRevenue += amt;

            String monthKey = date.getYear() + "-" + String.format("%02d", date.getMonthValue());
            monthlyHistory.put(monthKey, monthlyHistory.getOrDefault(monthKey, 0.0) + amt);
        }

        return Map.of(
            "today", todayRevenue,
            "week", weekRevenue,
            "month", monthRevenue,
            "total", totalRevenue,
            "history", monthlyHistory
        );
    }

    public List<String> getAvailableSlots(Long doctorId, LocalDate date) {
        Doctor doctor = doctorRepository.findById(doctorId)
            .orElseThrow(() -> new RuntimeException("Doctor Record Not Found for ID: " + doctorId));

        if (doctor.getAppointmentsEnabled() != null && !doctor.getAppointmentsEnabled()) {
            return Collections.emptyList();
        }

        List<String> allSlots = parseSlots(doctor);
        LocalDateTime expiryTime = LocalDateTime.now().minusMinutes(10);
        List<Appointment> existing = new ArrayList<>();
        try {
            existing = appointmentRepository.findByDoctorIdAndAppointmentDate(doctorId, date);
        } catch (Exception e) {}
        
        Set<String> takenSlots = existing.stream()
            .filter(a -> a.getStatus() == Appointment.AppointmentStatus.BOOKED || 
                        a.getStatus() == Appointment.AppointmentStatus.AWAITING_VERIFICATION ||
                        (a.getStatus() == Appointment.AppointmentStatus.PENDING && a.getCreatedAt() != null && a.getCreatedAt().isAfter(expiryTime)))
            .map(a -> a.getTimeSlot())
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());

        ZoneId clinicalZone = ZoneId.of("Asia/Kolkata");
        return allSlots.stream()
            .filter(slot -> !takenSlots.contains(slot))
            .filter(slot -> {
                if (date.isEqual(LocalDate.now(clinicalZone))) {
                    try {
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH);
                        java.time.LocalTime slotTime = java.time.LocalTime.parse(slot.trim(), formatter);
                        return slotTime.isAfter(java.time.LocalTime.now(clinicalZone).plusMinutes(2));
                    } catch (Exception e) { return true; }
                }
                return true;
            })
            .collect(Collectors.toList());
    }

    private List<String> parseSlots(Doctor doctor) {
        String timings = doctor.getConsultationTimings();
        int duration = (doctor.getSlotDuration() != null && doctor.getSlotDuration() > 0) ? doctor.getSlotDuration() : 15;
        int buffer = (doctor.getSlotBuffer() != null) ? doctor.getSlotBuffer() : 0;
        
        if (timings == null || timings.trim().isEmpty() || !timings.contains("-")) {
            return Collections.emptyList();
        }

        try {
            String[] parts = timings.split("-");
            String startStr = parts[0].trim();
            String endStr = parts[1].trim();

            java.time.LocalTime startTime = parseRobustTime(startStr);
            java.time.LocalTime endTime = parseRobustTime(endStr);

            if (startTime == null || endTime == null) return Collections.emptyList();

            DateTimeFormatter displayFormatter = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH);
            List<String> slots = new ArrayList<>();
            java.time.LocalTime current = startTime;
            
            // Safety: prevent infinite loops if start >= end
            int maxIterations = 100; 
            int i = 0;
            while (current.isBefore(endTime) && i < maxIterations) {
                slots.add(current.format(displayFormatter));
                current = current.plusMinutes(duration + buffer);
                i++;
            }
            return slots;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    private java.time.LocalTime parseRobustTime(String timeStr) {
        String[] formats = {"hh:mm a", "h:mm a", "HH:mm", "H:mm", "hh:mma", "h:mma"};
        for (String format : formats) {
            try {
                return java.time.LocalTime.parse(timeStr.toUpperCase(), DateTimeFormatter.ofPattern(format, Locale.ENGLISH));
            } catch (Exception e) {}
        }
        return null;
    }

    public void syncDoctorCoordinates(Doctor doctor) {
        if (doctor.isInstitutional()) return; // Hospital handle coordinates for their staff

        try {
            String addr = doctor.getClinicAddress();
            if (addr == null || addr.trim().isEmpty()) {
                addr = String.join(", ", 
                    doctor.getClinicStreet() != null ? doctor.getClinicStreet() : "",
                    doctor.getClinicCity() != null ? doctor.getClinicCity() : "",
                    doctor.getClinicState() != null ? doctor.getClinicState() : "",
                    doctor.getClinicPinCode() != null ? doctor.getClinicPinCode() : ""
                );
            }
            
            if (addr.trim().isEmpty() || addr.trim().equals(", , ,")) return;

            String query = addr.replace(" ", "%20");
            URL url = new URL("https://nominatim.openstreetmap.org/search?format=json&q=" + query + "&limit=1");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "MediSync-HOS/1.0");

            if (conn.getResponseCode() == 200) {
                Scanner scanner = new Scanner(conn.getInputStream());
                StringBuilder response = new StringBuilder();
                while (scanner.hasNext()) response.append(scanner.nextLine());
                scanner.close();

                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(response.toString());
                if (root.isArray() && root.size() > 0) {
                    JsonNode location = root.get(0);
                    doctor.setLatitude(location.get("lat").asDouble());
                    doctor.setLongitude(location.get("lon").asDouble());
                    doctorRepository.save(doctor);
                    System.out.println("DEBUG: Coordinates synchronized for Dr. " + doctor.getName() + ": " + doctor.getLatitude() + ", " + doctor.getLongitude());
                }
            }
        } catch (Exception e) {
            System.err.println("CRITICAL: Failed to geocode doctor clinic: " + e.getMessage());
        }
    }
}
